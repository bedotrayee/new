import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-t1',
  templateUrl: './t1.component.html',
  styleUrls: ['./t1.component.css']
})
export class T1Component implements OnInit {
    name:' ';
    contact:' ';
    address:' ';
    arr=[];
   
  constructor(){ }
 
  ngOnInit() {  
  }
    
   add(){
    localStorage.setItem("name",name);
    localStorage.setItem("contact",this.contact);
    localStorage.setItem("address",this.address);
    var test={name:this.name,contact:this.contact,address:this.address};
    this.arr.push(test);
     
    localStorage.setItem("array",JSON.stringify(this.arr));
     console.log(this.arr);


}
}

  